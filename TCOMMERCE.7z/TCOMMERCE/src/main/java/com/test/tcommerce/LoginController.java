package com.test.tcommerce;

import java.io.IOException;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("login")
public class LoginController {

    //로그인 첫 화면 요청 메소드
	@RequestMapping(value="/login.do")
    public String login(Model model, HttpSession session) {
      
       
        return "login/login";
    }

	

    //로그아웃
	@RequestMapping(value="/logout.do")
    public String logout(HttpSession session)throws IOException {
        System.out.println("여기는 logout");
        session.invalidate();
        return "account/account_login";
    }
}