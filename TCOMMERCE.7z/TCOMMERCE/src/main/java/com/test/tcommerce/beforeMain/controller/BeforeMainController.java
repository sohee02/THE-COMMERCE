package com.test.tcommerce.beforeMain.controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.test.tcommerce.beforeMain.service.BeforeMainService;
import com.test.tcommerce.cmn.DTO;
import com.test.tcommerce.cmn.MessageVO;
import com.test.tcommerce.cmn.PcwkLogger;
import com.test.tcommerce.cmn.StringUtil;
import com.test.tcommerce.cmn.UserDTO;
import com.test.tcommerce.code.domain.CodeVO;
import com.test.tcommerce.code.service.CodeService;
import com.test.tcommerce.user.domain.UserVO;
import com.test.tcommerce.user.service.UserService;

@Controller
@RequestMapping("beforeMain")
public class BeforeMainController implements PcwkLogger {

	@Autowired
	BeforeMainService beforeMainService;


	@Autowired
	CodeService codeService;
	
	@Autowired
	UserService userService;


	

	@GetMapping(value = "/moveToUserMonitor.do")
	public ModelAndView moveToUserMonitor(ModelAndView modelAndView, UserDTO inVO) throws SQLException {
		if (null != inVO && inVO.getPageSize() == 0) {
			inVO.setPageSize(10L);
		}

		// 페이지 번호:1
		if (null != inVO && inVO.getPageNo() == 0) {
			inVO.setPageNo(1L);
		}

		// 검색구분:""
		if (null != inVO && null == inVO.getSearchDiv()) {
			inVO.setSearchDiv(StringUtil.nvl(inVO.getSearchDiv()));
		}
		// 검색어:""
		if (null != inVO && null == inVO.getSearchWord()) {
			inVO.setSearchDiv(StringUtil.nvl(inVO.getSearchWord()));
		}
		LOG.debug("Bulletin Default처리: " + inVO);
		
		Map<String, Object> codes = new HashMap<String, Object>();
		String[] codeStr = { "PAGE_SIZE", "USER_SEARCH" };

		codes.put("code", codeStr);
		List<CodeVO> codeList = codeService.doRetrieve(codes);

		List<CodeVO> userSearchList = new ArrayList<CodeVO>();
		List<CodeVO> pageSizeList = new ArrayList<CodeVO>();
		
		for (CodeVO vo : codeList) {
			if (vo.getCategory().equals("USER_SEARCH")) {
				userSearchList.add(vo);
			}

			if (vo.getCategory().equals("PAGE_SIZE")) {
				pageSizeList.add(vo);
			}
		}
		 List<UserVO> list = userService.doRetrieve(inVO);
		
		long totalCnt = 0;
		
		for(UserVO vo: list) {
			if(totalCnt == 0) {
				totalCnt = vo.getTotalCnt();
				break;
			}
		}
		modelAndView.addObject("totalCnt", totalCnt);
		
		modelAndView.setViewName("user/user_monitor");
		modelAndView.addObject("list", list);
		modelAndView.addObject("paramVO", inVO);
		modelAndView.addObject("userSearch", userSearchList);
		modelAndView.addObject("pageSize", pageSizeList);
		
		long bottomCount = StringUtil.BOTTOM_COUNT;// 바닥글
		String html = StringUtil.renderingPager(totalCnt, inVO.getPageNo(), inVO.getPageSize(), bottomCount,
				"/bdm/beforeMain/moveToUserMonitor.do", "pageDoRerive");
		modelAndView.addObject("pageHtml", html);

		String title = "회원 관리";
		modelAndView.addObject("title", title);
		
		
		return modelAndView;
	}

	@GetMapping(value = "/moveToFindPassword.do")
	public String moveToFindPassword() throws SQLException {
		return "account/account_findPassword";
	}

	@GetMapping(value = "/moveToFindId.do")
	public String moveToFindId() throws SQLException {
		return "account/account_findId";
	}

	@GetMapping(value = "/moveToLogin.do")
	public String moveToLogin() throws SQLException {
		return "account/account_login";
	}

	@GetMapping(value = "/moveToBeforeMain.do")
	public String moveToBeforeMain() throws SQLException {
		return "main/beforeLoginMain";
	}

	@GetMapping(value = "/moveToAfterMain.do")
	public String moveToAfterMain() throws SQLException {
		return "main/afterLoginMain";
	}

	

	@GetMapping(value = "/moveToBulletin.do")
	public String moveToBulletin() throws SQLException {
		return "board/bulletin";
	}


	@GetMapping(value = "/moveToMain.do")
	public String moveToMain(HttpSession httpSession) throws SQLException {
		if (httpSession.getAttribute("user") != null) {
			return "main/afterLoginMain";
		} else {
			return "main/beforeLoginMain";
		}

	}

	public static Date convertStringToDate(String dateString, String dateFormat) {
		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

		try {
			return formatter.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}

	

	

	@GetMapping(value = "/doLogout.do")
	public ModelAndView doLogout(DTO inVO, ModelAndView modelAndView, HttpSession httpSession) throws SQLException {

		if (inVO != null && inVO.getPageSize() == 0) {
			inVO.setPageSize(10L);
		}
		if (inVO != null && inVO.getPageNo() == 0) {
			inVO.setPageNo(1L);
		}

		if (inVO != null && inVO.getSearchWord() == null) {
			inVO.setSearchWord(StringUtil.nvl(inVO.getSearchWord()));
		}

		inVO.setSearchDiv("10");
		LOG.debug("inVO:" + inVO);
		
		
		HashMap<String, String> map = new HashMap<>();
		
	
		
		if (httpSession.getAttribute("user") != null) {
			httpSession.removeAttribute("user");
			httpSession.invalidate();
		}
		
		modelAndView.setViewName("main/beforeLoginMain");

		return modelAndView;
	}

	

	
	@RequestMapping(value = "/doLogin.do", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody // HTTP 요청 부분의 body부분이 그대로 브라우저에 전달된다.
	public String doLogin(UserVO user, HttpSession httpSession) throws SQLException {
		String jsonString = "";
		LOG.debug("┌───────────────────────────────────────────┐");
		LOG.debug("│ doLogin                                   │user:" + user);
		LOG.debug("└───────────────────────────────────────────┘");

		MessageVO message = new MessageVO();

		// 입력 validation
		// id null check
		if (null == user.getId() || "".equals(user.getId())) {
			message.setMsgId("1");
			message.setMsgContents("아이디를 입력 하세요.");

			jsonString = new Gson().toJson(message);
			LOG.debug("jsonString:" + jsonString);
			return jsonString;
		}

		// pass null check
		if (null == user.getPw() || "".equals(user.getPw())) {
			message.setMsgId("2");
			message.setMsgContents("비밀번호를 입력 하세요.");

			jsonString = new Gson().toJson(message);
			LOG.debug("jsonString:" + jsonString);
			return jsonString;
		}

		int check = beforeMainService.loginCheck(user);
		if (10 == check) { // id확인
			message.setMsgId("10");
			message.setMsgContents("아이디를 확인 하세요.");

		} else if (20 == check) { // 비번확인
			message.setMsgId("20");
			message.setMsgContents("비밀번호를 확인 하세요.");

		} else if (30 == check) {
			UserVO outVO = beforeMainService.doSelectOne(user);
			message.setMsgId("30");
			message.setMsgContents(outVO.getName() + "님 반갑습니다.");

			if (null != outVO) {
				httpSession.setAttribute("user", outVO);
			}
		} else {
			message.setMsgContents("오류가 발생 했습니다. 다시 시도해주세요.");
		}
		jsonString = new Gson().toJson(message);
		LOG.debug("jsonString:" + jsonString);

		return jsonString;
	}
}
