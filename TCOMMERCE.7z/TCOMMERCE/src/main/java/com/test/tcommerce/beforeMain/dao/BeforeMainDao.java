package com.test.tcommerce.beforeMain.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;

import com.test.tcommerce.cmn.DTO;
import com.test.tcommerce.user.domain.UserVO;

public interface BeforeMainDao {
	
	int idCheck(UserVO inVO)throws SQLException;
	
	int idPassCheck(UserVO inVO)throws Exception;

	UserVO doSelectOne(UserVO inVO) throws SQLException;

	UserVO doSelectOneByEmail(UserVO inVO) throws SQLException, EmptyResultDataAccessException;
}
