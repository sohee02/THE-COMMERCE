package com.test.tcommerce.beforeMain.service;

import java.sql.SQLException;


import org.springframework.dao.EmptyResultDataAccessException;

import com.test.tcommerce.user.domain.UserVO;

public interface BeforeMainService {

	int loginCheck(UserVO inVO)throws SQLException;

	UserVO doSelectOne(UserVO inVO) throws SQLException, EmptyResultDataAccessException;


	UserVO doSelectOneByEmail(UserVO inVO) throws SQLException, EmptyResultDataAccessException;
}