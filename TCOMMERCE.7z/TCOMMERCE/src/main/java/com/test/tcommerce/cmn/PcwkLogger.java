package com.test.tcommerce.cmn;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public interface PcwkLogger {
	
	Logger LOG = LogManager.getLogger(PcwkLogger.class);

}
