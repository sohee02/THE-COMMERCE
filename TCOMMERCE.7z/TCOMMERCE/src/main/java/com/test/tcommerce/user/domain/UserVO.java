package com.test.tcommerce.user.domain;

import com.test.tcommerce.cmn.UserDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserVO extends UserDTO {

	private String id;
	private int no;
	private String pw;
	private String nickName;
	private String name;
	private String phone;
	private String email;
	private String regDt;
	private int userFilter;
	private String salt;
	private String block;
	
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", no=" + no + ", pw=" + pw + ", nickName=" + nickName + ", name=" + name
				+ ", phone=" + phone + ", email=" + email + ", regDt=" + regDt + ", userFilter=" + userFilter
				+ ", salt=" + salt + ", block=" + block + ", toString()=" + super.toString() + "]";
	}
	


	
	
}
